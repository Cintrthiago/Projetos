# #001 - Profile Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/Cintrthiago/pen/ZEoZRwR](https://codepen.io/Cintrthiago/pen/ZEoZRwR).

